adings[0]; // set the max value to be the first element of the array
            minTemperature = tempReadings[0]; 